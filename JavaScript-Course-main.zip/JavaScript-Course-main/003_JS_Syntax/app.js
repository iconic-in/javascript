let firstName = 'Ali';
let age = 30;

firstName = 'Shovo';
FirstName = 'Hossain';
firstname = 'ali';

console.log(firstName);

console.log(age + 50);

function funcName() {
  console.log('My First Function');
}
funcName();
