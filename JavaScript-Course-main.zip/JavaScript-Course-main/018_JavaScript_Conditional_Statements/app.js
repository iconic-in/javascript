// JavaScript Conditional Statements

let age = 4;

if (age > 40) {
  console.log('You are old');
} else if (age > 18) {
  console.log('You are ready to open a Google Account');
} else if (age > 18) {
  console.log('You are ready to open a Google Account');
} else if (age > 18) {
  console.log('You are ready to open a Google Account');
} else if (age > 18) {
  console.log('You are ready to open a Google Account');
} else if (age > 18) {
  console.log('You are ready to open a Google Account');
} else {
  console.log('You are not ready');
}

let category = 'Truck';
let carType;

switch (category) {
  case 'car':
    carType = 'This is a Car';
    break;
  case 'Motor Bike':
    carType = 'This is a Motor Bike';
    break;
  case 'Truck':
    carType = 'This is a Truck';
    break;
  default:
    carType = 'Unknown Vehicle Category';
}

console.log(carType);

let person = {
  name: 'Alice',
  age: 25,
  occupation: 'Engineer',
};
